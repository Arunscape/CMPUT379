#include <stdio.h>
#include <unistd.h>
#include <signal.h>

int  i;

void quit(int signum) {
	fprintf(stderr, "\nInterrupt (code= %d, i= %d)\n", signum, i);
}

int main () {
	if(signal(SIGQUIT, quit) == SIG_ERR)
		perror("can′t catch SIGQUIT");
	for (i= 0; i < 9e7; i++)
		if (i % 1000 == 0) putc('.', stderr);
	return(0);
 }