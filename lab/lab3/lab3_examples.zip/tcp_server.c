#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/ip.h>
#include <stdio.h>
#include <string.h>

#define LISTENQ 10
#define MAXLINE 128
#define SERV_PORT 12345

void echo(int sockfd) {
    /* read content into a buffer, and write them back */
    ssize_t n;
    char buf[MAXLINE];
    while ((n = read(sockfd, buf, MAXLINE)) > 0) {
        write(sockfd, buf, n);
        if (n < 0) perror("write");
    }
    return;
}

int main() {
    int listenfd, connfd;
    struct sockaddr_in cliaddr, servaddr;
    socklen_t clilen;
    listenfd = socket(AF_INET, SOCK_STREAM, 0); /* create a listen socket */
    if (listenfd < 0) perror("listen socket");
    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY); 
    servaddr.sin_port = htons(SERV_PORT);
    bind(listenfd, (struct sockaddr *)&servaddr, sizeof(servaddr));
    if (bind < 0) perror("bind");
    if (listen(listenfd, 10) < 0) perror("listen");
    while (1) {
        connfd = accept(listenfd, (struct sockaddr*) &cliaddr, &clilen);
        if (connfd < 0) perror("accept");
        echo(connfd);
        close(connfd);
    }
}