#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

void* thread_function(void* args_p /* the input */) {
    int* num = (int *) args_p; /* cast the input to the type you want */
    printf("I'm in a new thread. I have number %d\n", *num);
    return NULL;
}

int main() {
    pthread_t thread_handle;
    int num_to_pass = 42;
    pthread_create(&thread_handle, NULL, thread_function, &num_to_pass);

    sleep(1);
    printf("I'm in the main thread!\n");
    pthread_join(thread_handle, NULL);
    return 0;
}