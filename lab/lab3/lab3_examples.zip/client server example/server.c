#include <unistd.h>
#include <netdb.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>

#define PORT        "1025"
#define BACKLOG     4
#define BUF_SIZE    20

int create_server_sock(char *port) {
    struct addrinfo *res, hints = {
        .ai_family = AF_INET6,
        .ai_socktype = SOCK_STREAM,
        .ai_flags = AI_PASSIVE || AI_V4MAPPED
    };

    int err, sfd;

    err = getaddrinfo(NULL, port, &hints, &res);
    if (err != 0) {
        fprintf(stderr, "gai_err %s\n", gai_strerror(err));
        return -1;
    }

    struct addrinfo *cur;

    for (cur = res; cur!= NULL; cur = cur->ai_next) {
        // create socket
        sfd = socket(cur->ai_family, cur->ai_socktype, cur->ai_protocol);
        if (sfd == -1) {
            perror("socket");
            continue;
        }

        // sock opt
        int val = 1;
        // may not want to use reuseaddr
        err = setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, &val, sizeof(val));
        if (err == -1) {
            perror("setsockopt");
            close(sfd);
            continue;
        }

        // bind
        err = bind(sfd, cur->ai_addr, cur->ai_addrlen);
        if (err == -1) {
            perror("bind");
            close(sfd);
            continue;
        }

        // listen
        err = listen(sfd, BACKLOG);
        if (err == -1) {
            perror("listen");
            close(sfd);
            continue;
        }

        break;
    }

    // free addrinfo
    freeaddrinfo(res);
    if (cur == NULL) {
        fprintf(stderr, "failed to create socket\n");
        close(sfd);
        return -1;
    }
    return sfd;
}

int main() {
    int sfd = create_server_sock(PORT);

    // do stuff
    struct sockaddr_storage client_addr;
    socklen_t client_addr_len = sizeof(client_addr);

    int cfd = accept(sfd, (struct sockaddr *) &client_addr, &client_addr_len);
    if (cfd == -1) {
        perror("accept");
        _exit(1);
    }

    int n;
    uint8_t buf[BUF_SIZE];

    while ((n = read(cfd, buf, BUF_SIZE)) > 0) {
        if (n == -1) {
            perror("read");
            _exit(1);
        }
        if (write(STDOUT_FILENO, buf, n) == -1) {
            perror("read");
            _exit(1);
        }
    }

    close(sfd);

    return 0;
}
