
A simple set of programs that use threads:
- `t0.c`
- `t1.c`

Each one depends on header files found in `../include`

The Makefile is simplistic but will do.


