#include <stdio.h>
#include <signal.h>
#include <unistd.h>

/*
 *  timer: run a program and terminate it after 1 second
 *  COMPILE IT: make
 *  TRY IT: run ./timer and try typing in /usr/bin/top
 */

int main() {
    char filename[100]; // create an array to store the filename
    scanf("%s", filename); // read a filename from the standard input
    int pid = fork();
    if (pid == 0) {
        // child process
        char* args[] = {filename, NULL};
        int return_value = execv(args[0], args); // run the program with the filename you just read
        if (return_value == -1) { // some error just occurred!  
            perror("execv failed"); // print the detailed error message.
        }
    } else {
        // parent process
        sleep(1); // wait for a second
        kill(pid, SIGKILL); // cruelly kill it
    }
}
