#include <stdio.h>

int magic();

int main() {
    printf("Hello world. %d\n", magic());
    return 0;
}
