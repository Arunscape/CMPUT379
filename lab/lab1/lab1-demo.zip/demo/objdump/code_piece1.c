#include <stdio.h>

int GLOBAL_MAGIC_NUMBER = 7;

int magic();

int main() {
    printf("Hello world. %d\n", magic());
    return 0;
}
