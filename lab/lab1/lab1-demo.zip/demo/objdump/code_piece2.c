int magic() {
    return 42;
}
