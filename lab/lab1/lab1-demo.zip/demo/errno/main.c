#include <stdio.h>
#include <errno.h>
#include <fcntl.h>

int main() {
    int fd = open("some_file_that_does_not_exist.txt", O_RDONLY);
    if (fd < 0) {
        // some error occurred.
        int errsv = errno; // save errno
        printf("Some error occurred, error number is: %d\n", errno);
        perror("Error message is");
        // handle specific error
        if (errsv == ENOENT) {
            printf("Handle specific error: the file does not exist.\n");
        }
    } else {
        printf("A file has been open. fd = %d\n", fd);
    }
    return 0;
}
