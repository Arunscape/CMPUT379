#include <stdlib.h>

int magic() {
    return 42;
}

int* get_leaky() {
    // Welcome to The Leaky Cauldron
    int* number = malloc(sizeof(int));
    *number = 42;
    return number;
}
