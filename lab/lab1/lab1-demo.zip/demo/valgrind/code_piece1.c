#include <stdio.h>

int magic();
int* get_leaky();

int main() {
    int magic_number;
    for (int i = 0; i < 100; i++) {
        // run 100 times to ensure no accident happens
        // (DEFINITELY WRONG, NEVER DO THIS)
        magic_number = *get_leaky();
    }
    printf("Hello world. %d\n", magic_number);
    return 0;
}
