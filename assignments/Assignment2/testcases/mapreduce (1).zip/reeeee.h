#ifndef REEEEE_H
#define REEEEE_H

#include <string>
void REEEEE(std::string msg);

#endif // REEEEE_H
