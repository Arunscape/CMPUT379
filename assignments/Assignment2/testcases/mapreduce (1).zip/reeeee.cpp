#include <iostream>

void REEEEE(std::string msg) {
  std::cerr << msg << std::endl;
  exit(1);
}
