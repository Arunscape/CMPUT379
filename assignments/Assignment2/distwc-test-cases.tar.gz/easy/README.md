# Usage:

just run ./test.sh

Place your MapReduce and Threadpool library in the directory above this.