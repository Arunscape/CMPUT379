#ifndef WELCOME_H_
#define WELCOME_H_

void printDragon();

#endif // WELCOME_H_