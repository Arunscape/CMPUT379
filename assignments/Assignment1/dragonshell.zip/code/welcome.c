#include <stdio.h>

#include "welcome_dragon.h"

void printDragon() { printf("%s", welcome_dragon); }