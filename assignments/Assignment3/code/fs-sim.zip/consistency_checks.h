#ifndef PROCESS_INPUT_H
#define PROCESS_INPUT_H
#include <stdint.h>

int8_t do_checks();

#endif
