#ifndef PROCESS_INPUT_H
#define PROCESS_INPUT_H

void process_input(const char *file);

#endif
